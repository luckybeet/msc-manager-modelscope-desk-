/* ═══════════════════════════════════════════
   魔搭方寸间 · 前端逻辑
   WebSocket 通信 + 面板切换 + UI 交互
   ═══════════════════════════════════════════ */

// ── 状态 ──
const WS_URL = 'ws://127.0.0.1:14027';
let ws = null;
let reqId = 0;
const pending = {};          // id → resolve
let currentPage = 1;
let currentQuery = '';
let currentModelId = null;   // 抽屉中查看的模型

// ── DOM 引用 ──
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ═══════════════════════════════════════════
// WebSocket
// ═══════════════════════════════════════════

function connectWS() {
  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    console.log('[WS] 已连接');
    updateWSStatus(true);
    loadEnvInfo();
    loadMyModels();
  };

  ws.onmessage = (e) => {
    const msg = JSON.parse(e.data);
    if (msg.type) {
      // 服务端推送
      handlePush(msg);
    } else if (msg.id && pending[msg.id]) {
      // 请求响应
      pending[msg.id](msg);
      delete pending[msg.id];
    }
  };

  ws.onclose = () => {
    updateWSStatus(false);
    console.log('[WS] 断开，3 秒后重连…');
    setTimeout(connectWS, 3000);
  };

  ws.onerror = () => { /* onclose 会处理 */ };
}

function call(method, params = {}) {
  return new Promise((resolve, reject) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      reject(new Error('WebSocket 未连接'));
      return;
    }
    const id = ++reqId;
    pending[id] = resolve;
    ws.send(JSON.stringify({ id, method, params }));
    // 超时
    setTimeout(() => {
      if (pending[id]) {
        delete pending[id];
        reject(new Error('请求超时'));
      }
    }, 30000);
  });
}

function updateWSStatus(connected) {
  const dot = $('#wsStatus .dot');
  const text = $('#wsText');
  if (connected) {
    dot.className = 'dot connected';
    text.textContent = '已连接';
    startLatencyPing();
  } else {
    dot.className = 'dot offline';
    text.textContent = '未连接';
    const lat = $('#wsLatency');
    if (lat) lat.textContent = '延迟 —';
  }
}

let _latencyTimer = null;

function startLatencyPing() {
  if (_latencyTimer) clearInterval(_latencyTimer);
  _latencyTimer = setInterval(async () => {
    const t0 = performance.now();
    try {
      await call('check_env');
      const ms = Math.round(performance.now() - t0);
      const lat = $('#wsLatency');
      if (lat) lat.textContent = `延迟 ${ms}ms`;
    } catch (_) {}
  }, 5000);
  // 立即测一次
  setTimeout(() => {
    const t0 = performance.now();
    call('check_env').then(() => {
      const ms = Math.round(performance.now() - t0);
      const lat = $('#wsLatency');
      if (lat) lat.textContent = `延迟 ${ms}ms`;
    }).catch(() => {});
  }, 500);
}

// ═══════════════════════════════════════════
// 推送处理
// ═══════════════════════════════════════════

function handlePush(msg) {
  switch (msg.type) {
    case 'download_progress':
      updateDownloadProgress(msg);
      break;
    case 'download_file_done':
      // 单个文件完成
      break;
    case 'download_complete':
      onDownloadComplete(msg);
      break;
    case 'download_error':
      onDownloadError(msg);
      break;
  }
}

// ═══════════════════════════════════════════
// 面板切换
// ═══════════════════════════════════════════

function switchPanel(name) {
  $$('.panel').forEach(p => p.classList.remove('active'));
  const panel = $(`#panel-${name}`);
  if (panel) panel.classList.add('active');

  // 面板初始化
  if (name === 'discover') loadDiscoverModels();
  if (name === 'mymodels') loadMyModels();
  if (name === 'downloads') loadDownloads();
  if (name === 'settings') { loadEnvInfo(); loadConfigEditor(); }
}

// ═══════════════════════════════════════════
// 配置编辑
// ═══════════════════════════════════════════

async function loadConfigEditor() {
  try {
    const r = await call('get_config');
    if (!r.ok) return;
    const cfg = r.config || {};
    if ($('#cfgDownloadDir')) $('#cfgDownloadDir').value = cfg.download_dir || '';
    if ($('#cfgWsPort')) $('#cfgWsPort').value = String(cfg.ws_port || '');
    if ($('#cfgWebPort')) $('#cfgWebPort').value = String(cfg.web_port || '');
  } catch (e) {
    // 静默
  }
}

async function saveConfig(key) {
  const inputMap = {
    'download_dir': 'cfgDownloadDir',
    'ws_port': 'cfgWsPort',
    'web_port': 'cfgWebPort'
  };
  const input = $(`#${inputMap[key]}`);
  if (!input) return;

  let val = input.value.trim();
  // 端口转数字
  if (key === 'ws_port' || key === 'web_port') {
    val = parseInt(val, 10);
    if (isNaN(val) || val < 1024) {
      alert('端口需为数字且 ≥1024');
      return;
    }
  }

  try {
    const r = await call('update_config', { key, value: val });
    if (r.ok) {
      alert(`${key} 已更新` + (key.endsWith('port') ? '，请重启应用生效' : ''));
    }
  } catch (e) {
    alert('保存失败: ' + e.message);
  }
}

function loadDiscoverModels() {
  // 复用 list_downloads，渲染到 discoverLocalList
  call('list_downloads').then(r => {
    if (!r.ok) return;
    const div = $('#discoverLocalList');
    if (!div) return;
    const items = (r.data && r.data.downloads) || [];
    if (items.length === 0) {
      div.innerHTML = '<p class="placeholder">暂无已下载模型</p>';
      return;
    }
    div.innerHTML = items.map(m => `
      <div class="model-row">
        <span class="name">${esc(m.model_id || m)}</span>
        <span class="size">${esc(m.size || '')}</span>
      </div>
    `).join('');
  }).catch(() => {});
}

// ═══════════════════════════════════════════
// 环境检测
// ═══════════════════════════════════════════

async function loadEnvInfo() {
  try {
    const r = await call('check_env');
    if (!r.ok) return;

    const d = r.data;
    $('#sdkVersion').textContent = `SDK ${d.modelscope_version}`;
    $('#pyVersion').textContent = `Py ${d.python_version.split(' ')[0]}`;

    // 设置面板
    const envDiv = $('#envInfo');
    if (!envDiv) return;

    const ok = d.modelscope_installed;
    envDiv.innerHTML = `
      <div class="set-card">
        <div class="label">Python 版本</div>
        <div class="value ${ok ? 'green' : 'red'}">${d.python_version}</div>
      </div>
      <div class="set-card">
        <div class="label">ModelScope SDK</div>
        <div class="value ${ok ? 'green' : 'red'}">${d.modelscope_version} ${ok ? '✅' : '❌'}</div>
      </div>
      <div class="set-card">
        <div class="label">平台</div>
        <div class="value">${d.platform}</div>
      </div>
      <div class="set-card">
        <div class="label">模型下载目录</div>
        <div class="value" style="font-size:12px">${d.download_dir}</div>
      </div>
      <div class="set-card">
        <div class="label">SDK 缓存目录</div>
        <div class="value" style="font-size:12px">${d.cache_dir}</div>
      </div>
    `;
  } catch (e) {
    console.error('check_env 失败:', e);
  }
}

// ═══════════════════════════════════════════
// 模型搜索（官网跳转）
// ═══════════════════════════════════════════

function doSearchOfficial() {
  const query = $('#searchInput').value.trim();
  if (!query) return;
  const url = `https://modelscope.cn/models?search=${encodeURIComponent(query)}`;
  call('open_url', { url }).catch(() => {});
  window.open(url, '_blank');
}

// 旧版本地搜索（已废弃，保留不删）
async function doSearch(page = 1) {
  const query = $('#searchInput').value.trim();
  if (!query) return;
  doSearchOfficial(); // 直接跳官网
}

function renderSearchResults(data) {
  const { models, total, page, page_size } = data;
  const container = $('#searchResults');

  if (!models || models.length === 0) {
    container.innerHTML = '<p class="placeholder">未找到模型，尝试搜索组织名（如 qwen、iic、baichuan）</p>';
    $('#searchPager').style.display = 'none';
    return;
  }

  container.innerHTML = models.map(m => renderModelRow(m)).join('');
  renderPager(total, page, page_size);
}

function renderModelRow(m) {
  // modelscope 返回的模型字段
  const name = m.Name || m.name || m.ModelId || m.model_id || '未知';
  const id = m.Name || m.ModelId || m.model_id || name;
  const task = m.Task || m.task || '模型';
  const org = id.split('/')[0] || '';
  const updated = m.GmtModified || m.updated_at || '';
  const downloads = m.Downloads || m.downloads || 0;

  return `
    <div class="model-row" data-model="${id}">
      <div class="m-icon">🧠</div>
      <div class="m-info">
        <div class="m-name">${esc(id)}</div>
        <div class="m-meta">
          <span>🏷️ ${esc(task)}</span>
          ${org ? `<span>🏢 ${esc(org)}</span>` : ''}
          ${updated ? `<span>📅 ${esc(updated).slice(0,10)}</span>` : ''}
        </div>
      </div>
      <div class="m-actions">
        <button onclick="event.stopPropagation();openDrawer('${esc(id)}')">详情</button>
        <button class="primary" onclick="event.stopPropagation();startDownload('${esc(id)}')">下载</button>
      </div>
    </div>
  `;
}

function renderPager(total, page, page_size) {
  const pager = $('#searchPager');
  const totalPages = Math.ceil(total / page_size);
  if (totalPages <= 1) { pager.style.display = 'none'; return; }

  pager.style.display = 'flex';
  pager.innerHTML = `
    <button onclick="doSearch(${page - 1})" ${page <= 1 ? 'disabled' : ''}>◀</button>
    <span class="page-info">${page} / ${totalPages}（共 ${total} 个）</span>
    <button onclick="doSearch(${page + 1})" ${page >= totalPages ? 'disabled' : ''}>▶</button>
  `;
}

// ═══════════════════════════════════════════
// 我的模型
// ═══════════════════════════════════════════

async function loadMyModels() {
  try {
    const r = await call('list_downloads');
    if (!r.ok) return;

    const container = $('#mymodelsList');
    if (!container) return;

    const { downloads, active } = r.data;
    const local = downloads || [];

    if (local.length === 0) {
      container.innerHTML = '<p class="placeholder">暂无已下载模型。去"模型发现"搜索并下载吧。</p>';
      return;
    }

    container.innerHTML = local.map(path => {
      const name = path.split('/').slice(-2).join('/') || path;
      return `
        <div class="model-row">
          <div class="m-icon">📁</div>
          <div class="m-info">
            <div class="m-name">${esc(name)}</div>
            <div class="m-meta">${esc(path)}</div>
          </div>
          <div class="m-actions">
            <button onclick="event.stopPropagation();openDir('${esc(path)}')">打开目录</button>
          </div>
        </div>
      `;
    }).join('');
  } catch (e) {
    console.error('loadMyModels 失败:', e);
  }
}

// ═══════════════════════════════════════════
// 下载管理
// ═══════════════════════════════════════════

async function startDownload(modelId) {
  try {
    const r = await call('download_model', { model_id: modelId });
    if (!r.ok) {
      toast(`下载失败: ${r.error}`);
      return;
    }
    toast(`开始下载: ${modelId}`);
    loadDownloads();
  } catch (e) {
    toast(`下载失败: ${e.message}`);
  }
}

async function loadDownloads() {
  try {
    const r = await call('list_downloads');
    if (!r.ok) return;

    const { active } = r.data;
    const actContainer = $('#activeDownloads');
    const doneContainer = $('#doneDownloads');

    // 活跃下载
    if (!active || Object.keys(active).length === 0) {
      if (actContainer) actContainer.innerHTML = '<p class="placeholder">暂无下载任务</p>';
    } else {
      if (actContainer) {
        actContainer.innerHTML = Object.entries(active).map(([id, info]) => `
          <div class="model-row">
            <div class="m-icon">⬇️</div>
            <div class="m-info">
              <div class="m-name">${esc(id)}</div>
              <div class="m-meta">状态: ${info.status}</div>
              ${info.percent !== undefined ? `
                <div class="progress-bar">
                  <div class="fill" style="width:${info.percent}%"></div>
                </div>
                <div class="progress-detail">
                  <span>${info.percent}%</span>
                </div>
              ` : ''}
            </div>
          </div>
        `).join('');
      }
    }
  } catch (e) {
    console.error('loadDownloads 失败:', e);
  }
}

function updateDownloadProgress(msg) {
  const { model_id, percent, filename } = msg;

  // 更新活跃下载面板
  const actContainer = $('#activeDownloads');
  if (actContainer && actContainer.children.length) {
    // 简单刷新
    loadDownloads();
  }

  // 更新底部迷你进度条
  const mini = $('#downloadMini');
  mini.innerHTML = `
    <div class="mini-item">
      ⬇️ ${esc(model_id)}
      <div class="mini-bar"><div class="fill" style="width:${percent}%"></div></div>
      ${percent}%
    </div>
  `;
}

function onDownloadComplete(msg) {
  toast(`✅ 下载完成: ${msg.model_id}`);
  $('#downloadMini').innerHTML = '';
  loadDownloads();
  loadMyModels();
}

function onDownloadError(msg) {
  toast(`❌ 下载失败: ${msg.model_id} — ${msg.error}`);
  loadDownloads();
}

// ═══════════════════════════════════════════
// 详情抽屉
// ═══════════════════════════════════════════

async function openDrawer(modelId) {
  currentModelId = modelId;

  try {
    const r = await call('get_model_info', { model_id: modelId });
    if (!r.ok) { toast('获取详情失败'); return; }

    const { info, files } = r.data;
    const name = info.Name || info.ModelId || modelId;
    const org = modelId.split('/')[0] || '';
    const task = info.Task || info.task || '模型';
    const desc = info.Description || info.description || '暂无描述';
    const tags = (info.Tags || info.tags || []).slice(0, 6);

    $('#drawerContent').innerHTML = `
      <h3>${esc(name)}</h3>
      <div class="d-org">${esc(org)}</div>
      <div class="d-desc">${esc(desc).slice(0, 300)}</div>
      <div class="d-section">
        <div class="d-section-title">任务类型</div>
        ${esc(task)}
      </div>
      ${tags.length ? `
      <div class="d-section">
        <div class="d-section-title">标签</div>
        ${tags.map(t => `<span class="d-tag">${esc(t)}</span>`).join('')}
      </div>
      ` : ''}
      ${files && files.length ? `
      <div class="d-section">
        <div class="d-section-title">文件（${files.length}）</div>
        ${files.slice(0, 20).map(f => `<div class="d-file">📄 ${esc(f.Name || f.name || f)}</div>`).join('')}
      </div>
      ` : ''}
      <div class="d-actions">
        <button onclick="startDownload('${esc(modelId)}')">📥 下载模型</button>
        <button class="secondary" onclick="openMSWebsite('${esc(modelId)}')">🔗 魔搭官网</button>
      </div>
    `;

    $('#drawerOverlay').classList.add('show');
    $('#drawer').classList.add('open');
  } catch (e) {
    toast(`获取详情失败: ${e.message}`);
  }
}

function closeDrawer() {
  $('#drawerOverlay').classList.remove('show');
  $('#drawer').classList.remove('open');
  currentModelId = null;
}

function openMSWebsite(page) {
  // 官网跳转映射
  const urls = {
    'datasets':  'https://modelscope.cn/datasets',
    'studios':   'https://modelscope.cn/studios',
    'models':    'https://modelscope.cn/models',
    'skills':    'https://modelscope.cn/skills',
    'mcp':       'https://modelscope.cn/mcp',
    'aigc':      'https://www.modelscope.cn/aigc/home',
    'service':   'https://modelscope.cn/docs/model-service/deployment/intro',
    'home':      'https://modelscope.cn/home',
  };
  const url = urls[page] || 'https://modelscope.cn';
  call('open_url', { url }).catch(() => {});
  window.open(url, '_blank');
}

// ═══════════════════════════════════════════
// 工具函数
// ═══════════════════════════════════════════

function openDir(path) {
  // 通知后端打开目录
  call('open_dir', { path }).catch(() => {});
}

function esc(s) {
  if (!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function toast(msg) {
  let el = $('#toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove('show'), 2500);
}

// ═══════════════════════════════════════════
// 启动
// ═══════════════════════════════════════════

connectWS();
