"""平台适配层 — 三平台差异全收在这里"""
import os
import sys
import subprocess
import json
from pathlib import Path


# ── 配置加载 ──

_CONFIG = None

def _load_config():
    """加载项目根目录下的 config.json"""
    global _CONFIG
    if _CONFIG is not None:
        return _CONFIG
    try:
        # config.json 和本文件同目录
        cfg_path = Path(__file__).parent / "config.json"
        if cfg_path.exists():
            _CONFIG = json.loads(cfg_path.read_text(encoding="utf-8"))
        else:
            _CONFIG = {}
    except Exception:
        _CONFIG = {}
    return _CONFIG

def get_config(key: str, default=None):
    """获取配置项"""
    cfg = _load_config()
    val = cfg.get(key)
    return val if val is not None else default


# ── 路径 ──

def cache_dir() -> str:
    """模型缓存目录"""
    configured = get_config("cache_dir")
    if configured:
        return os.path.expanduser(configured)
    # 默认
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Caches/modelscope")
    elif sys.platform == "win32":
        return os.path.expandvars(r"%LOCALAPPDATA%\modelscope\cache")
    else:
        return os.path.expanduser("~/.cache/modelscope")


def default_download_dir() -> str:
    """默认下载路径（可由用户配置）"""
    configured = get_config("download_dir")
    if configured:
        return os.path.expanduser(configured)
    if sys.platform == "darwin":
        return os.path.expanduser("~/模型库/modelscope")
    elif sys.platform == "win32":
        return os.path.expandvars(r"%USERPROFILE%\模型库\modelscope")
    else:
        return os.path.expanduser("~/模型库/modelscope")


# ── 端口 ──

def ws_port() -> int:
    return get_config("ws_port", 14027)

def web_port() -> int:
    return get_config("web_port", 14028)


# ── Python ──

def python_cmd() -> str:
    """当前可用的 Python 3.12 命令"""
    if sys.platform == "win32":
        return "python"
    return "python3.12"


def pip_install_cmd(package: str) -> list:
    """安装 pip 包的命令"""
    if sys.platform == "win32":
        return ["python", "-m", "pip", "install", package]
    return ["python3.12", "-m", "pip", "install", package]


def open_browser(url: str):
    """打开浏览器"""
    import webbrowser
    webbrowser.open(url)


# ── 检测 ──

def is_python_installed() -> bool:
    """检测系统是否有 Python"""
    try:
        subprocess.run([python_cmd(), "--version"],
                       capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def is_modelscope_installed() -> bool:
    """检测 modelscope SDK 是否已安装（当前进程内检测）"""
    try:
        import modelscope  # noqa: F401
        return True
    except ImportError:
        return False


# ── 扫描 ──

def scan_existing_downloads() -> list:
    """扫描本地已有的模型缓存"""
    dirs = []
    default = os.path.expanduser("~/.cache/modelscope/hub")
    if os.path.isdir(default):
        for entry in os.listdir(default):
            model_dir = os.path.join(default, entry)
            if os.path.isdir(model_dir):
                dirs.append(model_dir)
    custom = default_download_dir()
    if os.path.isdir(custom):
        for entry in os.listdir(custom):
            model_dir = os.path.join(custom, entry)
            if os.path.isdir(model_dir):
                dirs.append(model_dir)
    return dirs
