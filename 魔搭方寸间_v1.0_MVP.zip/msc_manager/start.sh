#!/bin/bash
# ═════════════════════════════════════════════════
# 魔搭方寸间 · 一键启动
# 自动检测 Python3，创建 venv，启动服务
# ═════════════════════════════════════════════════

cd "$(dirname "$0")"

echo "🏔️ 魔搭方寸间 · ModelScope Manager"
echo ""

VENV_DIR="venv_py312"
VENV_PYTHON="$VENV_DIR/bin/python3"

# 自动发现 Python3 命令
PYTHON_CMD=""
for cmd in python3.12 python3.11 python3.10 python3; do
    if command -v "$cmd" &>/dev/null; then
        PYTHON_CMD="$cmd"
        break
    fi
done

if [ -z "$PYTHON_CMD" ]; then
    echo "❌ 未找到 Python3，请先安装 Python 3.10+"
    read -p "按回车退出…"
    exit 1
fi

echo "使用 Python: $($PYTHON_CMD --version 2>&1)"

# 检查虚拟环境
if [ ! -f "$VENV_PYTHON" ]; then
    echo "创建虚拟环境…"
    "$PYTHON_CMD" -m venv "$VENV_DIR"
    echo "安装依赖…"
    "$VENV_DIR/bin/pip" install -r requirements.txt -q
    echo "✅ 环境就绪"
fi

echo "启动服务…"

# 直接用 venv 内的 python3 启动
"$VENV_PYTHON" server.py

echo ""
echo "服务已退出"
read -p "按回车关闭…"
