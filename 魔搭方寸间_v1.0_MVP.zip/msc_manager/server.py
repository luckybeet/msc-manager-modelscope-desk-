"""
魔搭方寸间 · WebSocket 后端
WebSocket 服务 (127.0.0.1:9527) + pywebview 桌面窗口
"""
import asyncio
import json
import sys
import os
from pathlib import Path

# 确保项目根在 sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from websockets.asyncio.server import serve
from modelscope.hub.api import HubApi
from modelscope.hub.snapshot_download import snapshot_download
from modelscope.hub.callback import ProgressCallback
import platform_adapters as pa

# ── 全局状态 ──
HOST = "127.0.0.1"
PORT = pa.ws_port()          # WebSocket（从 config 读取）
HTTP_PORT = pa.web_port()     # HTTP 静态文件（从 config 读取）
api = HubApi()
active_downloads: dict[str, dict] = {}  # model_id → {percent, speed, status}

# ── 消息路由表 ──
HANDLERS = {}


def register(method: str):
    """装饰器：注册 handler"""
    def decorator(fn):
        HANDLERS[method] = fn
        return fn
    return decorator


# ═══════════════════════════════════════════
# 服务端推送工具
# ═══════════════════════════════════════════

async def push(websocket, msg_type: str, **kwargs):
    """向客户端推送消息（无 id 字段）"""
    payload = {"type": msg_type, **kwargs}
    await websocket.send(json.dumps(payload, ensure_ascii=False, default=str))


# ═══════════════════════════════════════════
# MVP Handlers
# ═══════════════════════════════════════════

@register("check_env")
async def handle_check_env(websocket, **params):
    """检测环境：Python 版本、SDK 版本、依赖状态"""
    import modelscope
    return {
        "python_version": sys.version,
        "python_path": sys.executable,
        "modelscope_version": modelscope.__version__,
        "modelscope_installed": pa.is_modelscope_installed(),
        "platform": sys.platform,
        "download_dir": pa.default_download_dir(),
        "cache_dir": pa.cache_dir(),
    }


@register("search_models")
async def handle_search_models(websocket, query: str = "", page: int = 1,
                                page_size: int = 10, **params):
    """
    搜索模型。
    注：modelscope SDK 的 list_models 按组织列出，无通用关键词搜索。
    这里使用 query 作为 owner_or_group 进行模糊匹配。
    """
    try:
        result = api.list_models(
            owner_or_group=query or None,
            page_number=page,
            page_size=page_size,
        )
        # list_models 返回 {"Models": [...], "TotalCount": N}
        models = result.get("Models", [])
        total = result.get("TotalCount", len(models))

        return {
            "models": models,
            "total": total,
            "page": page,
            "page_size": page_size,
        }
    except Exception as e:
        return {"models": [], "total": 0, "page": page,
                "page_size": page_size, "notice": str(e)}


@register("get_model_info")
async def handle_get_model_info(websocket, model_id: str, revision: str | None = None,
                                 **params):
    """获取模型详情 + 文件列表"""
    info = api.get_model(model_id, revision=revision)
    files = api.get_model_files(model_id, revision=revision, recursive=True)

    return {
        "model_id": model_id,
        "info": info,
        "files": files if isinstance(files, list) else [],
    }


class WsProgressCallback(ProgressCallback):
    """
    WebSocket 进度回调。
    每下载一个文件，modelscope 创建一个 ProgressCallback 实例，
    调用 update(size) 和 end()。
    """

    def __init__(self, websocket, model_id: str, filename: str, file_size: int):
        super().__init__(filename, file_size)
        self._ws = websocket
        self._model_id = model_id
        self._filename = filename
        self._file_size = file_size
        self._last_size = 0

    def update(self, size: int):
        self._last_size = size
        pct = (size / self._file_size * 100) if self._file_size else 0
        # 用 asyncio 创建任务推送进度
        asyncio.create_task(
            push(self._ws, "download_progress",
                 model_id=self._model_id,
                 filename=self._filename,
                 percent=round(pct, 1),
                 downloaded=size,
                 total=self._file_size)
        )

    def end(self):
        asyncio.create_task(
            push(self._ws, "download_file_done",
                 model_id=self._model_id,
                 filename=self._filename)
        )


@register("download_model")
async def handle_download_model(websocket, model_id: str, revision: str | None = None,
                                 local_dir: str | None = None, **params):
    """触发模型下载，通过 ProgressCallback 推送进度"""
    download_dir = local_dir or pa.default_download_dir()
    os.makedirs(download_dir, exist_ok=True)

    active_downloads[model_id] = {"percent": 0, "status": "downloading"}

    # 创建进度回调工厂
    callbacks = []

    def make_callback(filename: str, file_size: int) -> WsProgressCallback:
        cb = WsProgressCallback(websocket, model_id, filename, file_size)
        callbacks.append(cb)
        return cb

    # 在后台线程中执行下载（snapshot_download 是同步阻塞的）
    loop = asyncio.get_event_loop()

    def _download():
        try:
            path = snapshot_download(
                model_id=model_id,
                revision=revision,
                local_dir=download_dir,
                progress_callbacks=callbacks,
            )
            active_downloads[model_id] = {"percent": 100, "status": "done",
                                          "path": path}
            asyncio.run_coroutine_threadsafe(
                push(websocket, "download_complete",
                     model_id=model_id, local_path=path),
                loop
            )
        except Exception as e:
            active_downloads[model_id] = {"percent": 0, "status": "error",
                                          "error": str(e)}
            asyncio.run_coroutine_threadsafe(
                push(websocket, "download_error",
                     model_id=model_id, error=str(e)),
                loop
            )

    await loop.run_in_executor(None, _download)

    return {"model_id": model_id, "status": "started",
            "download_dir": download_dir}


@register("list_downloads")
async def handle_list_downloads(websocket, **params):
    """列出已下载的模型"""
    downloads = pa.scan_existing_downloads()
    return {
        "downloads": downloads,
        "active": active_downloads,
    }


@register("open_url")
async def handle_open_url(websocket, url: str = "", **params):
    """在浏览器中打开 URL"""
    import webbrowser
    webbrowser.open(url)
    return {"ok": True}


@register("open_dir")
async def handle_open_dir(websocket, path: str = "", **params):
    """在文件管理器中打开目录"""
    import subprocess, sys
    if sys.platform == "darwin":
        subprocess.Popen(["open", path])
    elif sys.platform == "win32":
        subprocess.Popen(["explorer", path])
    else:
        subprocess.Popen(["xdg-open", path])
    return {"ok": True}


@register("update_config")
async def handle_update_config(websocket, key: str = "", value="", **params):
    """更新配置项"""
    cfg_path = Path(__file__).parent / "config.json"
    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    cfg[key] = value
    cfg_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    # 重载配置
    pa._CONFIG = None
    return {"ok": True, "key": key, "value": value}


@register("get_config")
async def handle_get_config(websocket, **params):
    """获取全部配置"""
    cfg = pa._load_config()
    return {"config": cfg}

# ═══════════════════════════════════════════
# WebSocket 服务
# ═══════════════════════════════════════════

async def ws_handler(websocket):
    """WebSocket 连接处理"""
    remote = websocket.remote_address
    print(f"[WS] 客户端连接: {remote}")

    try:
        async for raw in websocket:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send(json.dumps(
                    {"ok": False, "error": "无效的 JSON"}))
                continue

            req_id = msg.get("id")
            method = msg.get("method", "")
            params = msg.get("params", {})

            handler = HANDLERS.get(method)
            if not handler:
                await websocket.send(json.dumps({
                    "id": req_id, "ok": False,
                    "error": f"未知方法: {method}"
                }, ensure_ascii=False))
                continue

            try:
                result = await handler(websocket, **params)
                await websocket.send(json.dumps({
                    "id": req_id, "ok": True, "data": result
                }, ensure_ascii=False, default=str))
            except Exception as e:
                await websocket.send(json.dumps({
                    "id": req_id, "ok": False, "error": str(e)
                }, ensure_ascii=False))
    except Exception:
        pass
    finally:
        print(f"[WS] 客户端断开: {remote}")


# ═══════════════════════════════════════════
# HTTP 静态文件服务（独立端口）
# 解决 file:// 协议下 WebSocket 被 WKWebView 阻止的问题
# 前端从 http://127.0.0.1:14028 加载，WS 连 ws://127.0.0.1:14027
# ═══════════════════════════════════════════

WEB_DIR = Path(__file__).parent / "web"


def start_http_server():
    """在独立线程启动 HTTP 静态文件服务"""
    import http.server
    import socketserver

    os.chdir(str(WEB_DIR))

    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(WEB_DIR), **kwargs)

        def log_message(self, format, *args):
            pass  # 静默

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer((HOST, HTTP_PORT), Handler) as httpd:
        print(f"[魔搭方寸间] HTTP 静态服务: http://{HOST}:{HTTP_PORT}")
        httpd.serve_forever()


async def start_server():
    """启动 WebSocket 服务"""
    print(f"[魔搭方寸间] WebSocket 服务: ws://{HOST}:{PORT}")
    async with serve(ws_handler, HOST, PORT):
        await asyncio.Future()  # 永久运行


def start_webview():
    """启动 pywebview 桌面窗口"""
    import webview

    url = f"http://{HOST}:{HTTP_PORT}/index.html"
    print(f"[魔搭方寸间] 启动桌面窗口: {url}")

    window = webview.create_window(
        title="魔搭方寸间 · ModelScope Manager",
        url=url,
        width=1100,
        height=750,
        min_size=(800, 500),
        resizable=True,
    )
    webview.start()


def main():
    """主入口"""
    import time
    import threading

    # 1. 后台线程启动 WebSocket 服务
    threading.Thread(
        target=lambda: asyncio.run(start_server()),
        daemon=True,
    ).start()

    # 2. 后台线程启动 HTTP 静态文件服务
    threading.Thread(
        target=start_http_server,
        daemon=True,
    ).start()

    # 3. 等待服务就绪
    time.sleep(1.5)
    print("[魔搭方寸间] 服务就绪，启动桌面窗口...")

    # 4. 主线程启动 pywebview 窗口（阻塞）
    start_webview()


if __name__ == "__main__":
    main()
