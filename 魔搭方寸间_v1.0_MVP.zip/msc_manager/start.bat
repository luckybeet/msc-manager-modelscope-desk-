@echo off
chcp 65001 >nul
title 魔搭方寸间 · ModelScope Manager

echo 🏔️ 魔搭方寸间
echo.

REM 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未找到 Python，请先安装 Python 3.10+
    pause
    exit /b 1
)

REM 创建虚拟环境
if not exist venv_py312 (
    echo 创建虚拟环境…
    python -m venv venv_py312
    echo 安装依赖…
    call venv_py312\Scripts\pip install -r requirements.txt -q
    echo ✅ 环境就绪
)

echo 启动服务…
call venv_py312\Scripts\python server.py

echo.
echo 服务已退出
pause
